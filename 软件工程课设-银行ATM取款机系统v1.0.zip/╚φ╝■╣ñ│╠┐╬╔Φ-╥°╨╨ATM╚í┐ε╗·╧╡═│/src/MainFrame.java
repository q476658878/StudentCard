import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Color;

import javax.swing.JTextField;


public class MainFrame extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private String currentCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;
	/**
	 * Create the dialog.
	 */
	public MainFrame(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 632, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(52, 80, 164));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JButton button = new JButton(new ImageIcon("images/cash.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Cash cash = new Cash(currentCardNumber);
					cash.setVisible(true);
					dispose();
				}
			});
			button.setBounds(491, 50, 125, 50);
			contentPanel.add(button);
		}
		{
			JButton button = new JButton(new ImageIcon("images/deposit.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DepositDialog deposit = new DepositDialog(currentCardNumber);
					deposit.setVisible(true);
					dispose();
				}
			});
			button.setBounds(491, 177, 125, 50);
			contentPanel.add(button);
		}
		{
			JButton btnTransfer = new JButton(new ImageIcon("images/transfer.png"));
			btnTransfer.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					TransferDialog t = new TransferDialog(currentCardNumber);
					t.setVisible(true);
					dispose();
				}
			});
			btnTransfer.setBounds(0, 50, 125, 50);
			contentPanel.add(btnTransfer);
		}
		
		{
			JButton button = new JButton(new ImageIcon("images/exit.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			button.setBounds(491, 301, 125, 50);
			contentPanel.add(button);
		}
		{
			JButton button = new JButton(new ImageIcon("images/checkBalance.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					CheckBalanceDialog c = new CheckBalanceDialog(currentCardNumber);
					c.setVisible(true);
				}
			});
			button.setBounds(0, 177, 125, 50);
			contentPanel.add(button);
		}
		{
			JButton button = new JButton(new ImageIcon("images/checkHistory.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					CheckHistoryDialog history = new CheckHistoryDialog(currentCardNumber);
					history.setVisible(true);
				}
			});
			button.setBounds(0, 301, 125, 50);
			contentPanel.add(button);
		}
		{
			JLabel label = new JLabel("\u65E9\u4E0A\u597D\uFF01\u8BF7\u9009\u62E9\u6240\u9700\u670D\u52A1");
			label.setForeground(Color.WHITE);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setFont(new Font("宋体", Font.PLAIN, 20));
			label.setBounds(175, 37, 275, 52);
			contentPanel.add(label);
		}
		{
			JLabel lblGoodMorningPlease = new JLabel("Good morning! Please select servise");
			lblGoodMorningPlease.setForeground(Color.WHITE);
			lblGoodMorningPlease.setHorizontalAlignment(SwingConstants.CENTER);
			lblGoodMorningPlease.setFont(new Font("宋体", Font.PLAIN, 16));
			lblGoodMorningPlease.setBounds(159, 81, 304, 19);
			contentPanel.add(lblGoodMorningPlease);
		}
		{
			JLabel label = new JLabel("\u8D26\u6237\u4F59\u989D\uFF1A");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(210, 172, 90, 33);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel(tc.getBalance().toString());
			label.setForeground(Color.YELLOW);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(293, 175, 104, 26);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5143");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(396, 179, 30, 19);
			contentPanel.add(label);
		}
		{
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setForeground(Color.WHITE);
			lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 16));
			lblNewLabel.setBounds(220, 208, 226, 19);
			contentPanel.add(lblNewLabel);
			lblNewLabel.setText("Account Balance: ¥"+tc.getBalance().toString());
		}
	}

}
