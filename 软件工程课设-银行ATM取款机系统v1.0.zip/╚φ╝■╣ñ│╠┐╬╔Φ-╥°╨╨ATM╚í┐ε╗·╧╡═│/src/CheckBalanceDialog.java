import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class CheckBalanceDialog extends JDialog {
	private String currentCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;
	private final JPanel contentPanel = new JPanel();
	
	/**
	 * Create the dialog.
	 */
	public CheckBalanceDialog(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 632, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(52, 80, 164));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JButton button = new JButton(new ImageIcon("images/back.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			button.setBounds(491, 301, 125, 50);
			contentPanel.add(button);
		}
		JButton button1 = new JButton(new ImageIcon("images/ok.png"));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button1.setBounds(0, 301, 120, 50);
		contentPanel.add(button1);
		{
			JLabel lblGoodMorningPlease = new JLabel("您好！ " + tc.getUsername());
			lblGoodMorningPlease.setForeground(Color.WHITE);
			lblGoodMorningPlease.setHorizontalAlignment(SwingConstants.CENTER);
			lblGoodMorningPlease.setFont(new Font("宋体", Font.PLAIN, 16));
			lblGoodMorningPlease.setBounds(166, 128, 304, 19);
			contentPanel.add(lblGoodMorningPlease);
		}
		{
			JLabel label = new JLabel("您的账户余额为：");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(191, 172, 144, 33);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel(tc.getBalance().toString());
			label.setForeground(Color.YELLOW);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(352, 175, 54, 26);
			contentPanel.add(label);
		}
		{
			JLabel label = new JLabel("\u5143");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("宋体", Font.PLAIN, 18));
			label.setBounds(440, 179, 30, 19);
			contentPanel.add(label);
		}
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setForeground(Color.WHITE);
			lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 16));
			lblNewLabel.setBounds(220, 208, 226, 19);
			contentPanel.add(lblNewLabel);
			lblNewLabel.setText("Account Balance: ¥"+tc.getBalance().toString());
		}
	}

}
