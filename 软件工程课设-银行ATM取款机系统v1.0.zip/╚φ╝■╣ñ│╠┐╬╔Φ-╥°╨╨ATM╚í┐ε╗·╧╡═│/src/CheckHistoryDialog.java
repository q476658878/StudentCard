import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


public class CheckHistoryDialog extends JDialog {
	
	private JTable table;
	private JPanel contentPanel = new JPanel();
	private String currentCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;

	/**
	 * Create the dialog.
	 */
	public void updateTable(){	
		if(tc.getHistory() != null){
			String[] source = tc.getHistory().split(",");
		String[][] history = new String[source.length/4][4];
        for (int i = 0; i < source.length; i++) {
            if(i%4==0){
            	//time
            	history[i/4][0] = source[i];
            }
            else if(i%4==1){
            	//action
            	history[i/4][1] = source[i];
            }
            else if(i%4==2){
            	//amount
            	history[i/4][2] = source[i];
            }
            else if(i%4==3){
            	//amount
            	history[i/4][3] = source[i];
            }
        }
		DefaultTableModel model = (DefaultTableModel)table.getModel();	//�õ�����ģ��
		model.getDataVector().clear();	//�����������
		for (int i=0;i<source.length/4;i++) {
			model.addRow(history[i]);	//��������
		}
		table.setModel(model);	//����ģ��
		}
	}
	
	public CheckHistoryDialog(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 632, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(52, 80, 164));
		contentPanel.setForeground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		contentPanel.setLayout(null);
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(71, 49, 481, 237);
			contentPanel.add(scrollPane);
			{
				table = new JTable(){
					 public boolean isCellEditable(int row, int column)
	                  {
						 return false;//�����������༭
	                  }
				};
				table.setForeground(new Color(238, 130, 238));
				table.setBackground(new Color(224, 255, 255));
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
						"ʱ��", "����", "���" , "�˻����"
					}
				) );
			
				scrollPane.setViewportView(table);
			}
			updateTable();
		}
		{
			JButton button = new JButton(new ImageIcon("images/ok.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			button.setBounds(491, 301, 125, 50);
			contentPanel.add(button);
		}
		JButton button1 = new JButton(new ImageIcon("images/back.png"));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button1.setBounds(0, 301, 120, 50);
		contentPanel.add(button1);
	}

}
