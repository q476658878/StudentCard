import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class DepositDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	private String currentCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;
	/**
	 * Create the dialog.
	 */
	public DepositDialog(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 633, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u91D1\u989D\uFF1A");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setBounds(120, 110, 160, 35);
		contentPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(305, 113, 160, 32);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\uFF08\u6A21\u62DF\u653E\u94B1\uFF09");
		label_1.setForeground(Color.WHITE);
		label_1.setBounds(148, 155, 78, 15);
		contentPanel.add(label_1);
		
		JButton button = new JButton(new ImageIcon("images/back.png"));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				MainFrame m = new MainFrame(currentCardNumber);
				m.setVisible(true);
			}
		});
		button.setBounds(0, 261, 120, 50);
		contentPanel.add(button);
		
		JButton button_1 = new JButton(new ImageIcon("images/ok.png"));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().length()<1 || Double.parseDouble(textField.getText())%100 != 0){
					JOptionPane.showMessageDialog(null, "�����100Ԫֽ��", "", JOptionPane.INFORMATION_MESSAGE);
				}
				else{
					tc.setBalance(tc.getBalance()+Double.parseDouble(textField.getText()));
					String history;
					String date=(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
					if(tc.getHistory()!=null)
						tc.setHistory(tc.getHistory()+ "," + date + ",���," + textField.getText().toString() + "," + tc.getBalance().toString());
					else
						tc.setHistory(date + ",���," + textField.getText().toString() + "," + tc.getBalance().toString());
					test.merge(tc);
					JOptionPane.showMessageDialog(null, "���ɹ���", "", JOptionPane.INFORMATION_MESSAGE);
					dispose();
					MainFrame m = new MainFrame(currentCardNumber);
					m.setVisible(true);
				}
			}
		});
		button_1.setBounds(497, 261, 120, 50);
		contentPanel.add(button_1);
		
		JLabel lblPleaseInputAmount = new JLabel("Please Input Amount:");
		lblPleaseInputAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseInputAmount.setForeground(Color.WHITE);
		lblPleaseInputAmount.setFont(new Font("����", Font.PLAIN, 20));
		lblPleaseInputAmount.setBounds(120, 47, 309, 15);
		contentPanel.add(lblPleaseInputAmount);
	}

}
