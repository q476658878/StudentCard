// default package

import java.util.List;
import org.hibernate.LockOptions;
import org.hibernate.Query;
import org.hibernate.criterion.Example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 	* A data access object (DAO) providing persistence and search support for tb_cards entities.
 			* Transaction control of the save(), update() and delete() operations 
		can directly support Spring container-managed transactions or they can be augmented	to handle user-managed Spring transactions. 
		Each of these methods provides additional information for how to configure it for the desired type of transaction control. 	
	 * @see .tb_cards
  * @author MyEclipse Persistence Tools 
 */
public class tb_cardsDAO extends BaseHibernateDAO  {
	     private static final Logger log = LoggerFactory.getLogger(tb_cardsDAO.class);
		//property constants
	public static final String PASSWORD = "password";
	public static final String BALANCE = "balance";
	public static final String USERNAME = "username";
	public static final String HISTORY = "history";



    
    public void save(tb_cards transientInstance) {
        log.debug("saving tb_cards instance");
        try {
            getSession().save(transientInstance);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }
    
	public void delete(tb_cards persistentInstance) {
        log.debug("deleting tb_cards instance");
        try {
            getSession().delete(persistentInstance);
            log.debug("delete successful");
        } catch (RuntimeException re) {
            log.error("delete failed", re);
            throw re;
        }
    }
    
    public tb_cards findById( java.lang.String id) {
        log.debug("getting tb_cards instance with id: " + id);
        try {
            tb_cards instance = (tb_cards) getSession()
                    .get("tb_cards", id);
            return instance;
        } catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
    
    
    public List findByExample(tb_cards instance) {
        log.debug("finding tb_cards instance by example");
        try {
            List results = getSession()
                    .createCriteria("tb_cards")
                    .add(Example.create(instance))
            .list();
            log.debug("find by example successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
            log.error("find by example failed", re);
            throw re;
        }
    }    
    
    public List findByProperty(String propertyName, Object value) {
      log.debug("finding tb_cards instance with property: " + propertyName
            + ", value: " + value);
      try {
         String queryString = "from tb_cards as model where model." 
         						+ propertyName + "= ?";
         Query queryObject = getSession().createQuery(queryString);
		 queryObject.setParameter(0, value);
		 return queryObject.list();
      } catch (RuntimeException re) {
         log.error("find by property name failed", re);
         throw re;
      }
	}

	public List findByPassword(Object password
	) {
		return findByProperty(PASSWORD, password
		);
	}
	
	public List findByBalance(Object balance
	) {
		return findByProperty(BALANCE, balance
		);
	}
	
	public List findByUsername(Object username
	) {
		return findByProperty(USERNAME, username
		);
	}
	
	public List findByHistory(Object history
	) {
		return findByProperty(HISTORY, history
		);
	}
	

	public List findAll() {
		log.debug("finding all tb_cards instances");
		try {
			String queryString = "from tb_cards";
	         Query queryObject = getSession().createQuery(queryString);
			 return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
    public tb_cards merge(tb_cards detachedInstance) {
        log.debug("merging tb_cards instance");
        try {
            tb_cards result = (tb_cards) getSession()
                    .merge(detachedInstance);
            log.debug("merge successful");
            return result;
        } catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }

    public void attachDirty(tb_cards instance) {
        log.debug("attaching dirty tb_cards instance");
        try {
            getSession().saveOrUpdate(instance);
            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }
    
    public void attachClean(tb_cards instance) {
        log.debug("attaching clean tb_cards instance");
        try {
                      	getSession().buildLockRequest(LockOptions.NONE).lock(instance);
          	            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }
}