
public class User {
	private String sex;
	private String name;
	private String idCardNumber;
	private String mobileNumber;
	public String getName(){
		return name;
	}
	public String getSex(){
		return sex;
	}
	public String getIDCardNumber(){
		return idCardNumber;
	}
	public String getMobileNumber(){
		return mobileNumber;
	}
}
