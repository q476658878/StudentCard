import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class Cash extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;
	private String currentCardNumber;
	/**
	 * Create the dialog.
	 */
	public Cash(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		setBounds(100, 100, 632, 434);
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(52, 80, 164));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u9009\u62E9\u6216\u8F93\u5165\u53D6\u6B3E\u91D1\u989D\uFF1A");
		label.setForeground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("宋体", Font.PLAIN, 24));
		label.setBounds(144, 46, 336, 36);
		contentPanel.add(label);
		
		JLabel lblPleaseSelectOr = new JLabel("Please Select Or Enter Amount:");
		lblPleaseSelectOr.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseSelectOr.setForeground(Color.WHITE);
		lblPleaseSelectOr.setFont(new Font("宋体", Font.PLAIN, 18));
		lblPleaseSelectOr.setBounds(154, 92, 304, 21);
		contentPanel.add(lblPleaseSelectOr);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("宋体", Font.PLAIN, 26));
		textField.setBounds(186, 138, 248, 50);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton(new ImageIcon("images/200.png"));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("200");
			}
		});
		button.setBounds(0, 46, 120, 50);
		contentPanel.add(button);
		
		JButton btnNewButton = new JButton(new ImageIcon("images/500.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("500");
			}
		});
		btnNewButton.setBounds(0, 138, 120, 50);
		contentPanel.add(btnNewButton);
		
		JButton button_1 = new JButton(new ImageIcon("images/1000.png"));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("1000");
			}
		});
		button_1.setBounds(0, 233, 120, 50);
		contentPanel.add(button_1);
		
		JButton button_2 = new JButton(new ImageIcon("images/back.png"));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				MainFrame m = new MainFrame(currentCardNumber);
				m.setVisible(true);
			}
		});
		
		button_2.setBounds(0, 319, 120, 50);
		contentPanel.add(button_2);
		
		JLabel label_1 = new JLabel();
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("宋体", Font.PLAIN, 14));
		label_1.setBounds(186, 213, 248, 107);
		label_1.setText("<html><body>本机目前只提供100元纸币，<br>数目必须是100的整倍数。<br>"
				+ "¥100 Is Available.</body></html>");
		contentPanel.add(label_1);
		
		JButton btnNewButton_1 = new JButton(new ImageIcon("images/2000.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("2000");
			}
		});
		btnNewButton_1.setBounds(496, 46, 120, 50);
		contentPanel.add(btnNewButton_1);
		
		JButton button_3 = new JButton(new ImageIcon("images/5000.png"));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("5000");
			}
		});
		button_3.setBounds(496, 233, 120, 50);
		contentPanel.add(button_3);
		
		JButton button_4 = new JButton(new ImageIcon("images/3000.png"));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("3000");
			}
		});
		button_4.setBounds(496, 138, 120, 50);
		contentPanel.add(button_4);
		
		JButton button_5 = new JButton(new ImageIcon("images/ok.png"));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textField.getText().length()<1){
					JOptionPane.showMessageDialog(null, "请选择取款金额", "", JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					if( tc.getBalance().intValue() < Integer.parseInt(textField.getText().toString())){
					JOptionPane.showMessageDialog(null, "余额不足！当前余额为：" + tc.getBalance().toString() + "元", "", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
					}
					else if(Integer.parseInt(textField.getText().toString())%100 != 0){
						JOptionPane.showMessageDialog(null, "本机目前只提供100元纸币，数目必须是100的整倍数", "", JOptionPane.INFORMATION_MESSAGE);
						textField.setText("");
					}
					else{
						tc.setBalance(tc.getBalance()-Double.parseDouble(textField.getText().toString()));
						String date=(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
						if(tc.getHistory()!=null)
							tc.setHistory(tc.getHistory() + "," + date + ",取款,-" + Double.parseDouble(textField.getText().toString()) + "," + tc.getBalance().toString());
						else
							tc.setHistory(date + ",取款,-" + Double.parseDouble(textField.getText().toString()) + "," + tc.getBalance().toString());
						test.merge(tc);
						JOptionPane.showMessageDialog(null, "取款成功！", "", JOptionPane.INFORMATION_MESSAGE);
						dispose();
						MainFrame m = new MainFrame(currentCardNumber);
						m.setVisible(true);
					}
				}
				
			}
		});
		button_5.setBounds(496, 319, 120, 50);
		contentPanel.add(button_5);
	}

}
