import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class TransferChildDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private String currentCardNumber;
	private String targetCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards sourceCard,targetCard;


	/**
	 * Create the dialog.
	 */
	public TransferChildDialog(String cardNumber,String targetCardNumber) {
		currentCardNumber = cardNumber;
		this.targetCardNumber = targetCardNumber;
		sourceCard = test.findById(currentCardNumber);
		targetCard = test.findById(targetCardNumber);
		
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 633, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u91D1\u989D\uFF1A");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setBounds(120, 110, 160, 35);
		contentPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(305, 113, 160, 32);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton(new ImageIcon("images/ok.png"));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Double amount = Double.parseDouble(textField.getText());
				
				if(sourceCard.getBalance().intValue() < amount.intValue()){
					JOptionPane.showMessageDialog(null, "���㣡��ǰ���Ϊ��" + sourceCard.getBalance().toString() + "Ԫ", "", JOptionPane.INFORMATION_MESSAGE);
					textField.setText("");
				}
				
				else{
					int result = JOptionPane.showConfirmDialog(null, "ȷ��ת�˸�" + targetCard.getCardNumber() + 
						"��","����", JOptionPane.WARNING_MESSAGE);
					if (result==JOptionPane.YES_OPTION) {
					sourceCard.setBalance(sourceCard.getBalance()-amount);
					String date=(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());	
					if(sourceCard.getHistory()!=null)
						sourceCard.setHistory(sourceCard.getHistory() + "," + date + ",ת��,-" + textField.getText().toString() + "," + sourceCard.getBalance().toString());
					else
						sourceCard.setHistory(date + ",ת��,-" + textField.getText().toString() + "," + sourceCard.getBalance().toString());
					test.merge(sourceCard);
					
					if(targetCard.getHistory()!=null)
						targetCard.setHistory(targetCard.getHistory() + "," + date + ",ת��," + textField.getText().toString() + "," + targetCard.getBalance().toString());
					else
						targetCard.setHistory(date + ",ת��," + textField.getText().toString() + "," + targetCard.getBalance().toString());
					targetCard.setBalance(targetCard.getBalance()+amount);
					test.merge(targetCard);
					JOptionPane.showMessageDialog(null, "ת�˳ɹ���", "", JOptionPane.INFORMATION_MESSAGE);
					dispose();
					MainFrame m = new MainFrame(currentCardNumber);
					m.setVisible(true);
					}
				}
				
			}
		});
		button.setBounds(0, 261, 120, 50);
		contentPanel.add(button);
		
		JButton button_1 = new JButton(new ImageIcon("images/back.png"));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame m = new MainFrame(currentCardNumber);
				m.setVisible(true);
				dispose();
			}
		});
		button_1.setBounds(497, 261, 120, 50);
		contentPanel.add(button_1);
		
		JLabel lblPleaseInputAmount = new JLabel("Please Input Amount:");
		lblPleaseInputAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseInputAmount.setForeground(Color.WHITE);
		lblPleaseInputAmount.setFont(new Font("����", Font.PLAIN, 20));
		lblPleaseInputAmount.setBounds(120, 47, 309, 15);
		contentPanel.add(lblPleaseInputAmount);
	}
}
