// default package



/**
 * Abstracttb_cards entity provides the base persistence definition of the tb_cards entity. @author MyEclipse Persistence Tools
 */

public abstract class Abstracttb_cards  implements java.io.Serializable {


    // Fields    

     private String cardNumber;
     private String password;
     private Double balance;
     private String username;
     private String history;


    // Constructors

    /** default constructor */
    public Abstracttb_cards() {
    }

	/** minimal constructor */
    public Abstracttb_cards(String cardNumber, String password, Double balance, String username) {
        this.cardNumber = cardNumber;
        this.password = password;
        this.balance = balance;
        this.username = username;
    }
    
    /** full constructor */
    public Abstracttb_cards(String cardNumber, String password, Double balance, String username, String history) {
        this.cardNumber = cardNumber;
        this.password = password;
        this.balance = balance;
        this.username = username;
        this.history = history;
    }

   
    // Property accessors

    public String getCardNumber() {
        return this.cardNumber;
    }
    
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public Double getBalance() {
        return this.balance;
    }
    
    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }

    public String getHistory() {
        return this.history;
    }
    
    public void setHistory(String history) {
        this.history = history;
    }
   








}