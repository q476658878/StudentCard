import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class TransferDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private String currentCardNumber;
	private tb_cardsDAO test = new tb_cardsDAO();
	private tb_cards tc;
	/**
	 * Create the dialog.
	 */
	public TransferDialog(String cardNumber) {
		currentCardNumber = cardNumber;
		tc = test.findById(currentCardNumber);
		
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 631, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("\u8BF7\u8F93\u5165\u5B58\u6B3E\u5361\u53F7\uFF1A");
			label.setForeground(Color.WHITE);
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setFont(new Font("����", Font.PLAIN, 22));
			label.setBounds(205, 30, 198, 46);
			contentPanel.add(label);
		}
		{
			textField = new JTextField();
			textField.setBounds(98, 118, 422, 41);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JButton button = new JButton(new ImageIcon("images/ok.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					tb_cards t = null;
					t = test.findById(textField.getText().toString());
					if(t == null){
						JOptionPane.showMessageDialog(null, "û���ҵ��ÿ��ţ������Ƿ��������", "", JOptionPane.INFORMATION_MESSAGE);
						textField.setText("");
					}
					else if(((Object)currentCardNumber).equals(textField.getText())){
						JOptionPane.showMessageDialog(null, "���ܸ��Լ�ת�ˣ�", "", JOptionPane.INFORMATION_MESSAGE);
						textField.setText("");
					}
					else{
						dispose();
						TransferChildDialog tcd = new TransferChildDialog(currentCardNumber,textField.getText().toString());
						tcd.setVisible(true);
					}
				}
			});
			button.setBounds(0, 260, 120, 50);
			contentPanel.add(button);
		}
		{
			JButton button = new JButton(new ImageIcon("images/back.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
					MainFrame m = new MainFrame(currentCardNumber);
					m.setVisible(true);
				}
			});
			button.setBounds(495, 260, 120, 50);
			contentPanel.add(button);
		}
		{
			JLabel label = new JLabel();
			label.setForeground(Color.YELLOW);
			label.setBounds(194, 167, 228, 41);
			label.setText("<html><body>��ʾ�����㱣֤����Ŀ��ŵ�׼ȷ��</body></html>");
			contentPanel.add(label);
		}
		{
			JLabel lblPleaseInputThe = new JLabel("Please Input The Deposit Account:");
			lblPleaseInputThe.setForeground(Color.WHITE);
			lblPleaseInputThe.setFont(new Font("����", Font.PLAIN, 16));
			lblPleaseInputThe.setHorizontalAlignment(SwingConstants.CENTER);
			lblPleaseInputThe.setBounds(170, 86, 275, 15);
			contentPanel.add(lblPleaseInputThe);
		}
	}

}
