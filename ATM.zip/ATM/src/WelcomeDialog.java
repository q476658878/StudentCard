import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.SwingConstants;

import factory.HibernateSessionFactory;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class WelcomeDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	//-------------------test data------------------
	public static tb_cards t1 = new tb_cards("6217856000012311111","123456",100.00,"����",null);;
	public static tb_cards t2 = new tb_cards("6217856000012312369","654321",250.00,"����",null);
	public static tb_cards t3 = new tb_cards("6217856025012346390","123123",1.00,"����",null);
	public static tb_cardsDAO test = new tb_cardsDAO();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			WelcomeDialog dialog = new WelcomeDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			
			test.save(t1);
			test.save(t2);
			test.save(t3);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public WelcomeDialog() {
		setBounds(100, 100, 632, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("\u8F93\u5165\u5361\u53F7\uFF1A");
			label.setForeground(Color.WHITE);
			label.setFont(new Font("����", Font.PLAIN, 20));
			label.setBounds(69, 100, 117, 34);
			contentPanel.add(label);
		}
		{
			textField = new JTextField();
			textField.setBounds(176, 103, 319, 34);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JLabel label = new JLabel("\uFF08\u6A21\u62DF\u63D2\u5361\uFF09");
			label.setForeground(Color.WHITE);
			label.setBounds(79, 130, 79, 15);
			contentPanel.add(label);
		}
		{
			JButton button = new JButton(new ImageIcon("images/ok.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Session s = HibernateSessionFactory.getSession();
					Query q = s.createQuery("from tb_cards where cardNumber='"+ textField.getText().toString() +"'");
					List<String> l =  q.list();
					HibernateSessionFactory.closeSession();
					if(l.size()==0){
						JOptionPane.showMessageDialog(null, "û���ҵ��ÿ���", "", JOptionPane.INFORMATION_MESSAGE);
					}
					else{
						JOptionPane.showMessageDialog(null, "��½�ɹ���", "", JOptionPane.INFORMATION_MESSAGE);
					}
				}
			});
			button.setBounds(236, 230, 120, 50);
			contentPanel.add(button);
		}
		{
			JLabel lblInputYourAccount = new JLabel("Input Your Account:");
			lblInputYourAccount.setHorizontalAlignment(SwingConstants.CENTER);
			lblInputYourAccount.setForeground(Color.WHITE);
			lblInputYourAccount.setFont(new Font("����", Font.PLAIN, 16));
			lblInputYourAccount.setBounds(202, 42, 180, 15);
			contentPanel.add(lblInputYourAccount);
		}
	}

}
