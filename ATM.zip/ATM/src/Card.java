
public class Card {
	private String cardNumber;
	private User user;
	private String password;
	public String getCardNumber() {
		return cardNumber;
	}

	public User getUser() {
		return user;
	}

	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
}
