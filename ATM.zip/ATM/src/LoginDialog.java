import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.SwingConstants;


public class LoginDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			LoginDialog dialog = new LoginDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public LoginDialog() {
		setBounds(100, 100, 632, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel label = new JLabel("\u8F93\u5165\u5BC6\u7801\uFF1A");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setBounds(152, 107, 120, 64);
		contentPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(300, 127, 133, 33);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton(new ImageIcon("images/ok.png"));
		button.setBounds(486, 266, 130, 50);
		contentPanel.add(button);
		
		JButton btnNewButton = new JButton(new ImageIcon("images/exit.png"));
		btnNewButton.setBounds(0, 266, 130, 50);
		contentPanel.add(btnNewButton);
		
		JLabel lblInputPassword = new JLabel("Input Password:");
		lblInputPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblInputPassword.setFont(new Font("����", Font.PLAIN, 22));
		lblInputPassword.setForeground(Color.WHITE);
		lblInputPassword.setBounds(196, 54, 185, 15);
		contentPanel.add(lblInputPassword);
	}
}
