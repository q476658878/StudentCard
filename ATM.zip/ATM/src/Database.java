import java.util.Vector;


public class Database {
	private Vector<CardInfo> cardInfo;
	public void addCardInfo(CardInfo c){
		cardInfo.add(c);
	}
	public void removeCardInfo(String id){
		for(int i=0; i<cardInfo.size(); i++){
			if( cardInfo.get(i).getCard().getCardNumber() == id ){
				cardInfo.remove(i);
				break;
			}
		}
	}
	public Vector<CardInfo> getCardInfo(){
		return cardInfo;
	}
}
