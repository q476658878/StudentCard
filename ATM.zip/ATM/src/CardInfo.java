
public class CardInfo {
	private Card card;
	private Double balance;
	private String[][] history;
	public Card getCard() {
		return card;
	}
	public Double getBalance() {
		return balance;
	}
	public void addBalance(Double money) {
		this.balance += money;
	}
	public void minusBalance(Double money) {
		this.balance -= money;
	}
	public String[][] getHistory() {
		return history;
	}
	public void setHistory(String[][] history) {
		this.history = history;
	}
}
