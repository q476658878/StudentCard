import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class DepositDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DepositDialog dialog = new DepositDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DepositDialog() {
		setBounds(100, 100, 633, 434);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.setBackground(new Color(52, 80, 164));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u91D1\u989D\uFF1A");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setBounds(120, 110, 160, 35);
		contentPanel.add(label);
		
		textField = new JTextField();
		textField.setBounds(305, 113, 160, 32);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\uFF08\u6A21\u62DF\u653E\u94B1\uFF09");
		label_1.setForeground(Color.WHITE);
		label_1.setBounds(148, 155, 78, 15);
		contentPanel.add(label_1);
		
		JButton button = new JButton(new ImageIcon("images/ok.png"));
		button.setBounds(0, 261, 120, 50);
		contentPanel.add(button);
		
		JButton button_1 = new JButton(new ImageIcon("images/back.png"));
		button_1.setBounds(497, 261, 120, 50);
		contentPanel.add(button_1);
		
		JLabel lblPleaseInputAmount = new JLabel("Please Input Amount:");
		lblPleaseInputAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseInputAmount.setForeground(Color.WHITE);
		lblPleaseInputAmount.setFont(new Font("����", Font.PLAIN, 20));
		lblPleaseInputAmount.setBounds(120, 47, 309, 15);
		contentPanel.add(lblPleaseInputAmount);
	}

}
